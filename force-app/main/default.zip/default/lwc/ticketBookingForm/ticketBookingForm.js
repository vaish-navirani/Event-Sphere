import { LightningElement, track, api , wire} from 'lwc';
import createTicket from '@salesforce/apex/TicketController.createTicket';
import getUpcomingEvents from '@salesforce/apex/EventController.getUpcomingEvents';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
 

export default class TicketBookingForm extends LightningElement {
    @api eventId;
    @api eventName;
    @api startDate;
    @api venue;
    @api price; // Updated: Added price as an API property

    @track showForm = false;
    @track ticketName;
    @track ticketType;
    @track status;
    @track checkinStatus;
    @track contactmdId;
    @wire(getUpcomingEvents)
    wiredEvents({ data, error }) {
        if (data) {
            const myObject = JSON.parse(data);
            console.log(JSON.stringify(myObject));
            console.log(data);
            this.price = myObject.Price__c;
            this.error = undefined;
            
        } else if (error) {
            this.error = error;
            this.events = undefined;
        }
    }
    
    

    ticketTypeOptions = [
        { label: 'Regular', value: 'Regular' },
        { label: 'VIP', value: 'VIP' },
        { label: 'Early Bird', value: 'Early Bird' }
    ];

    statusOptions = [
        { label: 'Purchased', value: 'Purchased' },
        { label: 'Cancelled', value: 'Cancelled' },
        { label: 'Transferred', value: 'Transferred' }
    ];

    checkinStatusOptions = [
        { label: 'Checked-In', value: 'Checked-In' },
        { label: 'Not Checked-In', value: 'Not Checked-In' }
    ];

    // Show the form when "Book Ticket" is clicked
    handleShowForm() {
        this.showForm = true;
    }

    handleInputChange(event) {
        this[event.target.dataset.field] = event.target.value;
    }

    handleContactmdChange(event) {
        this.contactmdId = event.detail.value[0];
    }

    handleSubmit() {
        createTicket({
            ticketName: this.ticketName,
            ticketType: this.ticketType,
            price: parseFloat(this.price), // Already set from API, no need for user input
            status: this.status,
            checkinStatus: this.checkinStatus,
            contactmdId: this.contactmdId,
            eventDetailId: this.eventId
        })
        .then(() => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Ticket booked successfully!',
                    variant: 'success'
                })
            );

            this.showForm = false; // Hide form after booking
        })
        .catch(error => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: error.body.message,
                    variant: 'error'
                })
            );
        });
    }
}
