import { LightningElement, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import getUpcomingEvents from '@salesforce/apex/EventController.getUpcomingEvents';
import getCurrentUserContactId from '@salesforce/apex/UserController.getCurrentUserContactId';

export default class EventList extends NavigationMixin(LightningElement) {
    @track events;
    @track showBookingModal = false;
    @track selectedEventId;
    price;
    contactId;

    @wire(getUpcomingEvents)
    wiredEvents({ error, data }) {
        if (data) {
            this.events = data;
        } else if (error) {
            console.error('Error fetching events', error);
        }
    }

    @wire(getCurrentUserContactId)
    wiredContact({ error, data }) {
        if (data) {
            this.contactId = data;
        } else if (error) {
            console.error('Error fetching contact', error);
        }
    }

    // View Event Details - Navigates to the Event Detail Page
    handleViewEvent(event) {
        const eventId = event.target.dataset.id;
        console.log('Viewing details for event:', eventId);

        if (!eventId) {
            console.error('Event ID is undefined');
            return;
        }

        // Navigate to the standard record page for Event_Detail__c
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: eventId,
                objectApiName: 'Event_Detail__c',
                actionName: 'view'
            }
        });
    }

    // Open Booking Modal
    handleBookTicket(event) {
        this.selectedEventId = event.target.dataset.id;
        this.showBookingModal = true;
    }

    // Handle Booking Success
    handleSuccess(event) {
        this.showToast('Success', 'Ticket booked successfully!', 'success');
        this.closeBookingModal();
    }

    // Handle Booking Error
    handleError(event) {
        this.showToast('Error', 'Failed to book ticket.', 'error');
    }

    // Close Booking Modal
    closeBookingModal() {
        this.showBookingModal = false;
    }

    // Display Toast Messages
    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}
